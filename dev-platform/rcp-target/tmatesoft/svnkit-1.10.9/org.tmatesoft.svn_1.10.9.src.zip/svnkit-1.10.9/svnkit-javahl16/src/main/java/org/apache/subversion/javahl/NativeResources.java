package org.apache.subversion.javahl;

import org.apache.subversion.javahl.types.Version;

public class NativeResources {

    public static Version getVersion() {
        return null;
    }

    public static void loadNativeLibrary() {
        //see SVNKIT-662 for details
    }
}
