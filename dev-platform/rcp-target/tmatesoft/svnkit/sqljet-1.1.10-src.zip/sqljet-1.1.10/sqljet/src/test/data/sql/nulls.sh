sqlite3 nulls.db < nulls.sql
rm -f ./nulls.db
