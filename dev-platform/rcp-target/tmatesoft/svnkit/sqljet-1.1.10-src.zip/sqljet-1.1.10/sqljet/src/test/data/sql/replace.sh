sqlite3 replace.db < replace.sql
rm -f ./replace.db
