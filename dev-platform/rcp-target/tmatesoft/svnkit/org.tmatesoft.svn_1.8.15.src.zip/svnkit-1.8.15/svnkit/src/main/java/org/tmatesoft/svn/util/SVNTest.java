package org.tmatesoft.svn.util;

import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNProperties;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.io.SVNRepositoryFactory;

public class SVNTest {

    public static void main(String[] args) throws SVNException {

        final SVNURL url = SVNURL.parseURIEncoded("svn://192.168.9.10/trunk");
        final SVNRepository repos = SVNRepositoryFactory.create(url);

        try {
            final SVNProperties properties = new SVNProperties();
            repos.getFile("file.txt", 2L, properties, System.out);
            System.out.println("properties: " + properties);
        } finally {
            repos.closeSession();
        }
    }
}

